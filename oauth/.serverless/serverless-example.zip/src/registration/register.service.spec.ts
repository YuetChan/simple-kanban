import { RegisterService } from "./register.service";

describe('RegistrationService', () => {
  let svc: RegisterService;

  beforeEach(async () => { });

  it('should be defined', () => {
    expect(svc).toBeDefined();
  });

});